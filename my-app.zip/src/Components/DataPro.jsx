import Img1 from '../image/42nite.png'
import Img2 from '../image/cv-maker.png'
import Img3 from '../image/gameQuiz.png'
import Img4 from '../image/indianMart.png'
import Img5 from '../image/jinUstad.png'
import Img6 from '../image/loveCal.png'

const data = {
  cardDate: [
      {
        id: 1,
        img: Img1,
        btn:"angular",
        title: "Whats42nite",
      },
      {
        id: 2,
        img: Img2,
        btn:"angular",
        title: "Cv Maker App",
      },
      {
        id: 3,
        img: Img3,
        btn:"angular",
        title: "Quiz Game",
      },
      {
        id: 4,
        img: Img4,
        btn:"angular",
        title: "Indian Mart",
      },
      {
        id: 5,
        img: Img5,
        btn:"angular",
        title: "jinUstad",
      },
      {
        id: 6,
        img: Img6,
        btn:"angular",
        title: "Love Calculator",
      },
],
};
export default data;
